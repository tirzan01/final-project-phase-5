# SpoonacularApi.InlineObject10

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **String** | The username. | 
**id** | **Number** | The shopping list item id. | 
**hash** | **String** | The private hash for the username. | 


