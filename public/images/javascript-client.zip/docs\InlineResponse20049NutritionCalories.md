# SpoonacularApi.InlineResponse20049NutritionCalories

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Number** |  | 
**unit** | **String** |  | 
**confidenceRange95Percent** | [**InlineResponse20049NutritionCaloriesConfidenceRange95Percent**](InlineResponse20049NutritionCaloriesConfidenceRange95Percent.md) |  | 
**standardDeviation** | **Number** |  | 


