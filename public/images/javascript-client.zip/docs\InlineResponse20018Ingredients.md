# SpoonacularApi.InlineResponse20018Ingredients

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**image** | **String** |  | 
**include** | **Boolean** |  | 
**name** | **String** |  | 


