# SpoonacularApi.InlineResponse2003WinePairing

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pairedWines** | **[String]** |  | 
**pairingText** | **String** |  | 
**productMatches** | [**[InlineResponse2003WinePairingProductMatches]**](InlineResponse2003WinePairingProductMatches.md) |  | 


