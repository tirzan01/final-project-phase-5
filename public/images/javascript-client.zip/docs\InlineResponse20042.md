# SpoonacularApi.InlineResponse20042

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisles** | [**[InlineResponse20042Aisles]**](InlineResponse20042Aisles.md) |  | 
**cost** | **Number** |  | 
**startDate** | **Number** |  | 
**endDate** | **Number** |  | 


