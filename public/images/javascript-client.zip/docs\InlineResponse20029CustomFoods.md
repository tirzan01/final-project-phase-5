# SpoonacularApi.InlineResponse20029CustomFoods

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**title** | **String** |  | 
**servings** | **Number** |  | 
**imageUrl** | **String** |  | 
**price** | **Number** |  | 


