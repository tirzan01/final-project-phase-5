# SpoonacularApi.InlineResponse20038Value

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**servings** | **Number** |  | 
**id** | **Number** |  | 
**title** | **String** |  | 
**imageType** | **String** |  | 


