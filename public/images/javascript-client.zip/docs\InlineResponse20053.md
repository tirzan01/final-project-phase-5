# SpoonacularApi.InlineResponse20053

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**query** | **String** |  | 
**totalResults** | **Number** |  | 
**limit** | **Number** |  | 
**offset** | **Number** |  | 
**searchResults** | [**[InlineResponse20053SearchResults]**](InlineResponse20053SearchResults.md) |  | 


