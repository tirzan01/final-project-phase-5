# SpoonacularApi.InlineResponse20052

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**articles** | **[Object]** |  | 
**groceryProducts** | **[Object]** |  | 
**menuItems** | **[Object]** |  | 
**recipes** | **[Object]** |  | 


