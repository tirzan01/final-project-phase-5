# SpoonacularApi.InlineResponse20057

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**suggests** | [**InlineResponse20057Suggests**](InlineResponse20057Suggests.md) |  | 
**words** | **[Object]** |  | 


