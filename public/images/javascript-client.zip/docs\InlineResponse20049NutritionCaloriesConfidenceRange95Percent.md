# SpoonacularApi.InlineResponse20049NutritionCaloriesConfidenceRange95Percent

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**min** | **Number** |  | 
**max** | **Number** |  | 


