# SpoonacularApi.InlineResponse20041Items

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**slot** | **Number** |  | 
**position** | **Number** |  | 
**type** | **String** |  | 
**value** | [**InlineResponse20041Value**](InlineResponse20041Value.md) |  | [optional] 


