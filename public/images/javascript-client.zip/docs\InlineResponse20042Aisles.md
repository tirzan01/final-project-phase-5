# SpoonacularApi.InlineResponse20042Aisles

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aisle** | **String** |  | 
**items** | [**[InlineResponse20042Items]**](InlineResponse20042Items.md) |  | [optional] 


