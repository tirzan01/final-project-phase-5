# SpoonacularApi.InlineResponse20057Suggests

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**u** | **[Object]** |  | 


