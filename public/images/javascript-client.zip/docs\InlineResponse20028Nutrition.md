# SpoonacularApi.InlineResponse20028Nutrition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutrients** | [**[RecipesParseIngredientsNutritionNutrients]**](RecipesParseIngredientsNutritionNutrients.md) |  | 
**caloricBreakdown** | [**RecipesParseIngredientsNutritionCaloricBreakdown**](RecipesParseIngredientsNutritionCaloricBreakdown.md) |  | 


