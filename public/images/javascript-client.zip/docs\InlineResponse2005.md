# SpoonacularApi.InlineResponse2005

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**title** | **String** |  | 
**imageType** | **String** |  | 
**readyInMinutes** | **Number** |  | 
**servings** | **Number** |  | 
**sourceUrl** | **String** |  | 


