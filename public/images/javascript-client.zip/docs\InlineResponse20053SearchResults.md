# SpoonacularApi.InlineResponse20053SearchResults

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**totalResults** | **Number** |  | 
**results** | [**[InlineResponse20053Results]**](InlineResponse20053Results.md) |  | [optional] 


