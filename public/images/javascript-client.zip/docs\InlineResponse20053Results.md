# SpoonacularApi.InlineResponse20053Results

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**name** | **String** |  | 
**image** | **String** |  | 
**link** | **String** |  | 
**type** | **String** |  | 
**relevance** | **Number** |  | 
**content** | **String** |  | 


