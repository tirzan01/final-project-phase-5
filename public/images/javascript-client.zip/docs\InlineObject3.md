# SpoonacularApi.InlineObject3

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **String** | The username. | 
**_date** | **String** | The date in the format yyyy-mm-dd. | 
**hash** | **String** | The private hash for the username. | 


