# SpoonacularApi.InlineResponse20017

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cuisine** | **String** |  | 
**cuisines** | **[String]** |  | 
**confidence** | **Number** |  | 


