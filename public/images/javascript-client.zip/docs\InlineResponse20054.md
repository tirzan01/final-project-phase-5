# SpoonacularApi.InlineResponse20054

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**videos** | [**[InlineResponse20054Videos]**](InlineResponse20054Videos.md) |  | 
**totalResults** | **Number** |  | 


