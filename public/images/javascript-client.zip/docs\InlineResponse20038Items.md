# SpoonacularApi.InlineResponse20038Items

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**slot** | **Number** |  | 
**position** | **Number** |  | 
**type** | **String** |  | 
**value** | [**InlineResponse20038Value**](InlineResponse20038Value.md) |  | [optional] 


