# SpoonacularApi.InlineResponse2006

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recipes** | [**[InlineResponse2006Recipes]**](InlineResponse2006Recipes.md) |  | 


