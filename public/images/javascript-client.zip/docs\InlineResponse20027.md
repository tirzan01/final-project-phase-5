# SpoonacularApi.InlineResponse20027

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**products** | [**[InlineResponse2007]**](InlineResponse2007.md) |  | 
**totalProducts** | **Number** |  | 
**type** | **String** |  | 
**offset** | **Number** |  | 
**_number** | **Number** |  | 


