# SpoonacularApi.InlineResponse20044

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pairings** | **[String]** |  | 
**text** | **String** |  | 


