# SpoonacularApi.InlineResponse20012

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **String** |  | 
**carbs** | **String** |  | 
**fat** | **String** |  | 
**protein** | **String** |  | 
**bad** | **[Object]** |  | 
**good** | **[Object]** |  | 


