# SpoonacularApi.InlineResponse20035

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**menuItems** | [**[InlineResponse20035MenuItems]**](InlineResponse20035MenuItems.md) |  | 
**totalMenuItems** | **Number** |  | 
**type** | **String** |  | 
**offset** | **Number** |  | 
**_number** | **Number** |  | 


