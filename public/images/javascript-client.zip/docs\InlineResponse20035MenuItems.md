# SpoonacularApi.InlineResponse20035MenuItems

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**title** | **String** |  | 
**restaurantChain** | **String** |  | 
**image** | **String** |  | 
**imageType** | **String** |  | 
**servings** | [**InlineResponse20028Servings**](InlineResponse20028Servings.md) |  | [optional] 


