# SpoonacularApi.InlineResponse2007

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**title** | **String** |  | 
**imageType** | **String** |  | 


