# SpoonacularApi.InlineResponse20051

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**annotations** | **[Object]** |  | 


