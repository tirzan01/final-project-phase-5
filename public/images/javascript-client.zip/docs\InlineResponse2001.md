# SpoonacularApi.InlineResponse2001

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**image** | **String** |  | 
**imageType** | **String** |  | 
**likes** | **Number** |  | 
**missedIngredientCount** | **Number** |  | 
**missedIngredients** | [**[RecipesFindByIngredientsMissedIngredients]**](RecipesFindByIngredientsMissedIngredients.md) |  | 
**title** | **String** |  | 
**unusedIngredients** | **[Object]** |  | 
**usedIngredientCount** | **Number** |  | 
**usedIngredients** | [**[RecipesFindByIngredientsMissedIngredients]**](RecipesFindByIngredientsMissedIngredients.md) |  | 
**** | **String** |  | [optional] 


