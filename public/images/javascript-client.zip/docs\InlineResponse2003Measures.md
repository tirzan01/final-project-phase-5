# SpoonacularApi.InlineResponse2003Measures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**InlineResponse2003MeasuresMetric**](InlineResponse2003MeasuresMetric.md) |  | 
**us** | [**InlineResponse2003MeasuresMetric**](InlineResponse2003MeasuresMetric.md) |  | 


