# SpoonacularApi.InlineResponse20050

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**answer** | **String** |  | 
**image** | **String** |  | 


