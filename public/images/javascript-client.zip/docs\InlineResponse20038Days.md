# SpoonacularApi.InlineResponse20038Days

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nutritionSummary** | [**InlineResponse20038NutritionSummary**](InlineResponse20038NutritionSummary.md) |  | [optional] 
**nutritionSummaryBreakfast** | [**InlineResponse20038NutritionSummary**](InlineResponse20038NutritionSummary.md) |  | [optional] 
**nutritionSummaryLunch** | [**InlineResponse20038NutritionSummary**](InlineResponse20038NutritionSummary.md) |  | [optional] 
**nutritionSummaryDinner** | [**InlineResponse20038NutritionSummary**](InlineResponse20038NutritionSummary.md) |  | [optional] 
**_date** | **Number** |  | 
**day** | **String** |  | 
**items** | [**[InlineResponse20038Items]**](InlineResponse20038Items.md) |  | [optional] 


