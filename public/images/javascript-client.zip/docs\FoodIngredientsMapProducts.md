# SpoonacularApi.FoodIngredientsMapProducts

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**title** | **String** |  | 
**upc** | **String** |  | 


