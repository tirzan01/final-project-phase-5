# SpoonacularApi.InlineResponse20040Items

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**day** | **Number** |  | 
**slot** | **Number** |  | 
**position** | **Number** |  | 
**type** | **String** |  | 
**value** | [**InlineResponse20040Value**](InlineResponse20040Value.md) |  | [optional] 


