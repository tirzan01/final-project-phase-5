# SpoonacularApi.InlineResponse20025Results

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**name** | **String** |  | 
**image** | **String** |  | 


