# SpoonacularApi.InlineResponse20010Amount

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metric** | [**InlineResponse20010AmountMetric**](InlineResponse20010AmountMetric.md) |  | 
**us** | [**InlineResponse20010AmountMetric**](InlineResponse20010AmountMetric.md) |  | 


