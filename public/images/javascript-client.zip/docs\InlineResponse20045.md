# SpoonacularApi.InlineResponse20045

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pairedWines** | **[String]** |  | 
**pairingText** | **String** |  | 
**productMatches** | [**[InlineResponse20045ProductMatches]**](InlineResponse20045ProductMatches.md) |  | 


