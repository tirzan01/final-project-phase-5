# SpoonacularApi.InlineResponse20040

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**items** | [**[InlineResponse20040Items]**](InlineResponse20040Items.md) |  | 
**publishAsPublic** | **Boolean** |  | 


