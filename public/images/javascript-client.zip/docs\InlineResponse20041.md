# SpoonacularApi.InlineResponse20041

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**name** | **String** |  | 
**days** | [**[InlineResponse20041Days]**](InlineResponse20041Days.md) |  | 


