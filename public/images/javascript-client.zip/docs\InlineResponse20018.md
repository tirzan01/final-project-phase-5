# SpoonacularApi.InlineResponse20018

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dishes** | [**[InlineResponse20018Dishes]**](InlineResponse20018Dishes.md) |  | 
**ingredients** | [**[InlineResponse20018Ingredients]**](InlineResponse20018Ingredients.md) |  | 
**cuisines** | **[String]** |  | 
**modifiers** | **[String]** |  | 


