# SpoonacularApi.InlineResponse20047

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recommendedWines** | [**[InlineResponse20047RecommendedWines]**](InlineResponse20047RecommendedWines.md) |  | 
**totalFound** | **Number** |  | 


