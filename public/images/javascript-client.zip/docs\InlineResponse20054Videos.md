# SpoonacularApi.InlineResponse20054Videos

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  | 
**length** | **Number** |  | 
**rating** | **Number** |  | 
**shortTitle** | **String** |  | 
**thumbnail** | **String** |  | 
**views** | **Number** |  | 
**youTubeId** | **String** |  | 


