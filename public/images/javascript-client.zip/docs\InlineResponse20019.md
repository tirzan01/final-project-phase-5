# SpoonacularApi.InlineResponse20019

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sourceAmount** | **Number** |  | 
**sourceUnit** | **String** |  | 
**targetAmount** | **Number** |  | 
**targetUnit** | **String** |  | 
**answer** | **String** |  | 


