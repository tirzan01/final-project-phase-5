# SpoonacularApi.InlineResponse20028Servings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_number** | **Number** |  | 
**size** | **Number** |  | 
**unit** | **String** |  | 


