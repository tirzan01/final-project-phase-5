# SpoonacularApi.InlineResponse20010

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredients** | [**[InlineResponse20010Ingredients]**](InlineResponse20010Ingredients.md) |  | 
**totalCost** | **Number** |  | 
**totalCostPerServing** | **Number** |  | 


