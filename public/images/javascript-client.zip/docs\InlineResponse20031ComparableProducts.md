# SpoonacularApi.InlineResponse20031ComparableProducts

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **[Object]** |  | 
**likes** | **[Object]** |  | 
**price** | **[Object]** |  | 
**protein** | [**[InlineResponse20031ComparableProductsProtein]**](InlineResponse20031ComparableProductsProtein.md) |  | 
**spoonacularScore** | [**[InlineResponse20031ComparableProductsProtein]**](InlineResponse20031ComparableProductsProtein.md) |  | 
**sugar** | **[Object]** |  | 


