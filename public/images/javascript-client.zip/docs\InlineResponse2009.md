# SpoonacularApi.InlineResponse2009

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**equipment** | **[Object]** |  | 


