# SpoonacularApi.InlineResponse20041Value

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**title** | **String** |  | 
**imageType** | **String** |  | 


