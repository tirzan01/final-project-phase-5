# SpoonacularApi.InlineResponse20039

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**templates** | [**[InlineResponse20013Ingredients1]**](InlineResponse20013Ingredients1.md) |  | 


