# SpoonacularApi.InlineResponse20031

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**comparableProducts** | [**InlineResponse20031ComparableProducts**](InlineResponse20031ComparableProducts.md) |  | 


