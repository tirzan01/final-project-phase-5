# SpoonacularApi.InlineResponse20013

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parsedInstructions** | [**[InlineResponse20013ParsedInstructions]**](InlineResponse20013ParsedInstructions.md) |  | 
**ingredients** | [**[InlineResponse20013Ingredients1]**](InlineResponse20013Ingredients1.md) |  | 
**equipment** | [**[InlineResponse20013Ingredients1]**](InlineResponse20013Ingredients1.md) |  | 


