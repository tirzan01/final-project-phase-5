# SpoonacularApi.InlineResponse20042Items

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**name** | **String** |  | 
**measures** | [**InlineResponse20042Measures**](InlineResponse20042Measures.md) |  | [optional] 
**pantryItem** | **Boolean** |  | 
**aisle** | **String** |  | 
**cost** | **Number** |  | 
**ingredientId** | **Number** |  | 


