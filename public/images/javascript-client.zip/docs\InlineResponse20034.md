# SpoonacularApi.InlineResponse20034

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**original** | **String** |  | 
**originalName** | **String** |  | 
**ingredientImage** | **String** |  | 
**meta** | **[String]** |  | 
**products** | [**[FoodIngredientsMapProducts]**](FoodIngredientsMapProducts.md) |  | 


