# SpoonacularApi.InlineResponse20056

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**answerText** | **String** |  | 
**media** | **[Object]** |  | 


