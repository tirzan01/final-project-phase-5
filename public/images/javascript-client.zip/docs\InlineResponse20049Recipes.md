# SpoonacularApi.InlineResponse20049Recipes

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**title** | **String** |  | 
**imageType** | **String** |  | 
**url** | **String** |  | 


