# SpoonacularApi.InlineResponse20046

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**wineDescription** | **String** |  | 


