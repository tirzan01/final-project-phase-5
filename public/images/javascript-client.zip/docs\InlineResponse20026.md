# SpoonacularApi.InlineResponse20026

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ingredient** | **String** |  | 
**substitutes** | **[String]** |  | 
**message** | **String** |  | 


